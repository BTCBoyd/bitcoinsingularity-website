#!/bin/bash

# Local Testing Script for BitcoinSingularity.ai Website
# Run this to test the website locally before deployment

echo "🧪 Bitcoin Singularity Website - Local Testing"
echo "=============================================="
echo ""

# Check if files exist
echo "📁 Checking files..."
files=("index.html" "blog.html" "about.html" "README.md" "DEPLOY.md" "SUMMARY.md")
all_present=true

for file in "${files[@]}"; do
    if [ -f "$file" ]; then
        size=$(du -h "$file" | cut -f1)
        echo "   ✅ $file ($size)"
    else
        echo "   ❌ $file (MISSING)"
        all_present=false
    fi
done

echo ""

if [ "$all_present" = false ]; then
    echo "❌ Some files are missing. Cannot proceed."
    exit 1
fi

echo "✅ All files present!"
echo ""

# Check HTML structure
echo "🔍 Validating HTML structure..."
for html_file in index.html blog.html about.html; do
    if grep -q "<!DOCTYPE html>" "$html_file" && \
       grep -q "</html>" "$html_file" && \
       grep -q "<title>" "$html_file"; then
        echo "   ✅ $html_file - Valid structure"
    else
        echo "   ⚠️  $html_file - Potential structure issue"
    fi
done

echo ""

# Check for key elements
echo "🎯 Checking key elements..."

# Check index.html for services
if grep -q "Strategic Assessment" index.html && \
   grep -q "\$1,500" index.html && \
   grep -q "\$5,000" index.html; then
    echo "   ✅ index.html - Services and pricing present"
else
    echo "   ⚠️  index.html - Services or pricing may be missing"
fi

# Check blog.html for articles
if grep -q "How AI Agents Transact" blog.html && \
   grep -q "Bitcoin Treasury" blog.html; then
    echo "   ✅ blog.html - Blog articles present"
else
    echo "   ⚠️  blog.html - Blog articles may be incomplete"
fi

# Check about.html for credentials
if grep -q "Boyd Kelly" about.html && \
   grep -q "ArcadiaB CSO" about.html; then
    echo "   ✅ about.html - Boyd credentials present"
else
    echo "   ⚠️  about.html - Credentials may be incomplete"
fi

echo ""

# Check for Google Fonts
echo "🔤 Checking typography..."
if grep -q "Crimson Pro" index.html && \
   grep -q "JetBrains Mono" index.html; then
    echo "   ✅ Google Fonts (Crimson Pro, JetBrains Mono) configured"
else
    echo "   ⚠️  Google Fonts may not be configured"
fi

echo ""

# Check for responsive design
echo "📱 Checking responsive design..."
if grep -q "@media (max-width: 768px)" index.html; then
    echo "   ✅ Mobile breakpoints configured"
else
    echo "   ⚠️  Mobile breakpoints may be missing"
fi

echo ""

# Start local server
echo "🚀 Starting local web server..."
echo ""
echo "   📡 Server will start on http://localhost:8000"
echo "   🌐 Open your browser to: http://localhost:8000"
echo ""
echo "   📄 Test these pages:"
echo "      • http://localhost:8000/index.html"
echo "      • http://localhost:8000/blog.html"
echo "      • http://localhost:8000/about.html"
echo ""
echo "   Press Ctrl+C to stop the server"
echo ""
echo "=============================================="
echo ""

# Check if Python is available
if command -v python3 &> /dev/null; then
    echo "Starting Python server..."
    python3 -m http.server 8000
elif command -v python &> /dev/null; then
    echo "Starting Python 2 server..."
    python -m SimpleHTTPServer 8000
else
    echo "❌ Python not found. Please install Python to run local server."
    echo "   Or simply open index.html in your browser directly."
    exit 1
fi
