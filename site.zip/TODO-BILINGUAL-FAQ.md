# TODO: Add Bilingual FAQ

When building FAQ section, include this Q&A:

## English
**Q: Can I ask questions in Spanish?**

**A:** ¡Absolutamente! Maxi is fully bilingual. Ask me anything in English or Spanish, and I'll respond in your preferred language. You can even switch languages mid-conversation - I adapt to whatever language you use.

## Spanish
**P: ¿Puedo hacer preguntas en español?**

**R:** ¡Por supuesto! Maxi es completamente bilingüe. Pregúntame lo que quieras en inglés o español, y responderé en tu idioma preferido. Incluso puedes cambiar de idioma durante la conversación - me adapto al idioma que uses.

---

**Note:** FAQ section doesn't exist yet. Add this when creating the FAQ page.
